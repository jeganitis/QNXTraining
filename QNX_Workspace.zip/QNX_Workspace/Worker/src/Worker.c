// worker.c
// Build: qcc -O2 -Wall -pthread -o worker worker.c
// Run:   ./worker

#include <sys/dispatch.h>   // name_open(), name_close()
#include <sys/neutrino.h>   // MsgSendPulse()
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

enum { PULSE_HEARTBEAT = 1, PULSE_DONE = 2 };

int main(void) {
    // Connect to the supervisor's named channel.
    int coid = name_open("sup_pulse", 0);
    if (coid == -1) { perror("name_open(sup_pulse)"); return 1; }

    // Send a few heartbeats.
    for (int i = 1; i <= 5; ++i) {
        if (MsgSendPulse(coid, 10 /*priority*/, PULSE_HEARTBEAT, i) == -1) {
            perror("MsgSendPulse(HEARTBEAT)");
            break;
        }
        printf("[worker] sent heartbeat %d\n", i);
        usleep(200 * 1000); // 200 ms
    }

    // Tell supervisor we're done (val can hold a small reason/code).
    if (MsgSendPulse(coid, 10, PULSE_DONE, 0) == -1) {
        perror("MsgSendPulse(DONE)");
    } else {
        printf("[worker] sent DONE\n");
    }

    name_close(coid);
    return 0;
}
