/*
 * pthread_many_consumers_qnx.c
 * QNX/POSIX: many threads consuming a shared counter with a mutex
 */

/*#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

#define NUM_THREADS 100

static long int Resource_count = 5000000;
static pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;

static void* Appl_CB(void* arg) {
    (void)arg;
    long consumed = 0;

    for (;;) {
        pthread_mutex_lock(&mut);
        if (Resource_count > 0) {
            --Resource_count;
            ++consumed;
            pthread_mutex_unlock(&mut);
        } else {
            pthread_mutex_unlock(&mut);
            break; // nothing left to consume
        }
    }

    printf("Application (tid=%lu) consumed %ld resource\n",
           (unsigned long)pthread_self(), consumed);
    return NULL;
}

int main(void) {
    pthread_t threads[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; ++i) {
        if (pthread_create(&threads[i], NULL, Appl_CB, NULL) != 0) {
            perror("pthread_create");
            exit(EXIT_FAILURE);
        }
    }

    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    printf("All Applications Completed Execution. Remaining=%ld\n", Resource_count);
    return 0;
}*/


/*
 * starvation_fifo_qnx.c
 * Demonstrate starvation of later threads using SCHED_FIFO priorities on QNX.*/


#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <sched.h>
#include <string.h>

#define NUM_THREADS        100
#define NUM_HOGS           10      // first N threads get high priority
#define HIGH_PRIO          60      // adjust to your system's range
#define LOW_PRIO           20
#define INITIAL_RESOURCES  5000000

static long Resource_count = INITIAL_RESOURCES;
static pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;

typedef struct {
    int id;
    int is_hog;   // 1 = high-priority thread, 0 = low-priority thread
} thread_arg_t;

static void* Appl_CB(void* arg) {
    thread_arg_t* a = (thread_arg_t*)arg;
    long consumed = 0;

#ifdef __QNXNTO__
    // Helps identify in Momentics / pidin
    char name[16];
    snprintf(name, sizeof(name), "%s%02d", a->is_hog ? "HOG" : "LOW", a->id);
    pthread_setname_np(pthread_self(), name);
#endif

    // High-priority HOG threads do tight loops; low-priority threads politely yield,
    // further increasing starvation.
    for (;;) {
        pthread_mutex_lock(&mut);
        if (Resource_count > 0) {
            --Resource_count;
            ++consumed;
            pthread_mutex_unlock(&mut);
        } else {
            pthread_mutex_unlock(&mut);
            break;
        }

        if (!a->is_hog) {
            struct timespec ts = {0, 2000000}; // 2 ms
            nanosleep(&ts, NULL);
        }
    }

    printf("[%s %2d | tid=%lu] consumed %ld\n",
           a->is_hog ? "HOG" : "LOW", a->id, (unsigned long)pthread_self(), consumed);

    return NULL;
}

static void create_thread_fifo(pthread_t* t, thread_arg_t* a, int priority) {
    pthread_attr_t attr;
    struct sched_param sp;
    int rc;

    pthread_attr_init(&attr);

    // Use EXPLICIT scheduling to apply our policy/priority
    rc = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
    if (rc) { errno = rc; perror("pthread_attr_setinheritsched"); exit(EXIT_FAILURE); }

    rc = pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    if (rc) { errno = rc; perror("pthread_attr_setschedpolicy"); exit(EXIT_FAILURE); }

    sp.sched_priority = priority;
    rc = pthread_attr_setschedparam(&attr, &sp);
    if (rc) { errno = rc; perror("pthread_attr_setschedparam"); exit(EXIT_FAILURE); }

    rc = pthread_create(t, &attr, Appl_CB, a);
    if (rc) {
        // If EPERM, explain the likely cause
        errno = rc;
        fprintf(stderr, "pthread_create(SCHED_FIFO prio=%d) failed: %s\n",
                priority, strerror(errno));
        if (rc == EPERM) {
            fprintf(stderr, "Hint: Need real-time privileges (try running as root on QNX).\n");
        }
        exit(EXIT_FAILURE);
    }

    pthread_attr_destroy(&attr);
}

int main(void) {
    pthread_t threads[NUM_THREADS];
    thread_arg_t args[NUM_THREADS];

    printf("Starting %d threads: %d high-priority HOGs (FIFO %d), %d low (FIFO %d)\n",
           NUM_THREADS, NUM_HOGS, HIGH_PRIO, NUM_THREADS - NUM_HOGS, LOW_PRIO);

    // Create high-priority HOG threads first
    for (int i = 0; i < NUM_HOGS; ++i) {
        args[i] = (thread_arg_t){ .id = i, .is_hog = 1 };
        create_thread_fifo(&threads[i], &args[i], HIGH_PRIO);
    }
    // Then create low-priority threads
    for (int i = NUM_HOGS; i < NUM_THREADS; ++i) {
        args[i] = (thread_arg_t){ .id = i, .is_hog = 0 };
        create_thread_fifo(&threads[i], &args[i], LOW_PRIO);
    }

    // Join all threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(threads[i], NULL);
    }

    printf("\nAll threads finished. Remaining=%ld (should be 0). "
           "If starvation occurred, most consumption came from HOG threads.\n",
           Resource_count);

    return 0;
}

