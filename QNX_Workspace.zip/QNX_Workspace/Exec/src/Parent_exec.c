/*
 * parent_exec.c
 * Demonstrates process creation with fork() and exec() in QNX
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

int main(void) {
    pid_t pid;

    printf("Parent process started. PID: %d\n", getpid());

    pid = fork();
    if (pid < 0) {
        perror("fork");
        exit(EXIT_FAILURE);
    }
    else if (pid == 0) {
        // Child process: Replace with new program
        printf("Child before exec(), PID: %d\n", getpid());

        char *args[] = {"child_program", "arg1", "arg2", NULL};

        // Replace this process image with child_program
        execv("./Child_Exec", args);

        // If execv returns, an error occurred
        perror("execv");
        exit(EXIT_FAILURE);
    }
    else {
        // Parent process: Wait for child to finish
        printf("Parent waiting for child PID %d...\n", pid);
        wait(NULL);
        printf("Parent done.\n");
    }

    return 0;
}
