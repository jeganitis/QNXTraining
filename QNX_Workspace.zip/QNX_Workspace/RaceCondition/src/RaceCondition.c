/*
 * pthread_shared_ops_qnx.c
 * QNX/POSIX version using pthreads and pthread mutex
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

static unsigned int Shared_Resource = 1;          // start with one
static pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;

static void cpu_work(unsigned long workUnits) {
    // Busy work to simulate computation
    volatile unsigned long x = 0;
    for (unsigned long i = 0; i < workUnits * 1000000UL; ++i) {
        x++;
    }
}

static void* Doubler(void* arg) {
    (void)arg;
    cpu_work(1); // do a bit of work first

    pthread_mutex_lock(&mut);
    Shared_Resource *= 2;
    printf("Doubler DOUBLED the shared resource.\n");
    pthread_mutex_unlock(&mut);

    return NULL;
}

static void* Summer(void* arg) {
    (void)arg;
    cpu_work(1); // do a bit of work first

    pthread_mutex_lock(&mut);
    Shared_Resource += 3;
    printf("Summer ADDED 3 to the shared resource.\n");
    pthread_mutex_unlock(&mut);

    return NULL;
}

int main(void) {
    pthread_t T[20];

    // Launch 5 pairs: Doubler + Summer
    for (int i = 0; i < 20; i += 2) {
        if (pthread_create(&T[i],   NULL, Doubler, NULL) != 0) { perror("pthread_create Doubler"); exit(EXIT_FAILURE); }
        if (pthread_create(&T[i+1], NULL, Summer,  NULL) != 0) { perror("pthread_create Summer");  exit(EXIT_FAILURE); }
    }

    // Join all threads
    for (int i = 0; i < 10; ++i) {
        pthread_join(T[i], NULL);
    }

    printf("Final Value of Shared Resource: %u\n", Shared_Resource);
    return 0;
}

/*
// pthread_shared_ops_qnx_posix.c
// Build (QNX): qcc -o pthread_shared_ops_qnx_posix pthread_shared_ops_qnx_posix.c -pthread
// (pick your variant, e.g. -Vgcc_ntox86_64 or -Vgcc_ntoaarch64le)
// Or with gcc/clang on POSIX: gcc -O2 -Wall -pthread -o pthread_shared_ops_qnx_posix pthread_shared_ops_qnx_posix.c

#define _XOPEN_SOURCE 700  // enable POSIX barrier on many libcs
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define NUM_THREADS 10
#define NUM_PAIRS   (NUM_THREADS/2)

static unsigned int Shared_Resource = 1;           // start with one
static pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;
static pthread_barrier_t barr;                     // barrier for 10 worker threads

static void cpu_work(unsigned long workUnits) {
    volatile unsigned long x = 0;
    for (unsigned long i = 0; i < workUnits * 1000000UL; ++i) {
        x++;
    }
}

static void* Doubler(void* arg) {
    (void)arg;
    cpu_work(1);                                   // do a bit of work first

    pthread_mutex_lock(&mut);
    Shared_Resource *= 2;
    printf("Doubler DOUBLED the shared resource.\n");
    pthread_mutex_unlock(&mut);

    // wait for all threads (both Doublers and Summers) to arrive
    int rv = pthread_barrier_wait(&barr);
    if (rv != 0 && rv != PTHREAD_BARRIER_SERIAL_THREAD) {
        perror("pthread_barrier_wait (Doubler)");
    }
    return NULL;
}

static void* Summer(void* arg) {
    (void)arg;

    // wait until all threads reach the barrier;
    // guarantees all Doublers finished before Summers proceed
    int rv = pthread_barrier_wait(&barr);
    if (rv != 0 && rv != PTHREAD_BARRIER_SERIAL_THREAD) {
        perror("pthread_barrier_wait (Summer)");
    }

    cpu_work(1);                                   // do a bit of work first
    pthread_mutex_lock(&mut);
    Shared_Resource += 3;
    pthread_mutex_unlock(&mut);
    printf("Summer ADDED 3 to the shared resource.\n");

    return NULL;
}

int main(void) {
    pthread_t T[NUM_THREADS];

    if (pthread_barrier_init(&barr, NULL, NUM_THREADS) != 0) {
        perror("pthread_barrier_init");
        exit(EXIT_FAILURE);
    }

    // Launch 5 pairs: Doubler + Summer
    for (int i = 0; i < NUM_THREADS; i += 2) {
        if (pthread_create(&T[i],   NULL, Doubler, NULL) != 0) { perror("pthread_create Doubler"); exit(EXIT_FAILURE); }
        if (pthread_create(&T[i+1], NULL, Summer,  NULL) != 0) { perror("pthread_create Summer");  exit(EXIT_FAILURE); }
    }

    // Join all threads
    for (int i = 0; i < NUM_THREADS; ++i) {
        pthread_join(T[i], NULL);
    }

    pthread_barrier_destroy(&barr);

    // Deterministic result:
    // Start = 1 → after 5 Doublers: 1 * 2^5 = 32 → after 5 Summers: 32 + 3*5 = 47
    printf("Final Value of Shared Resource: %u\n", Shared_Resource);
    return 0;
}*/

