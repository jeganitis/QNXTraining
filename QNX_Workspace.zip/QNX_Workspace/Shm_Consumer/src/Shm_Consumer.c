// shm_consumer.c
// Build (QNX): qcc -O2 -Wall -pthread -o shm_consumer shm_consumer.c
// Run:         ./shm_consumer

#define _XOPEN_SOURCE 700
#include <pthread.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>

#define SHM_NAME   "/pc_shm_demo"
#define RING_SIZE  8

typedef struct {
    pthread_mutex_t mtx;
    pthread_cond_t  not_empty;
    pthread_cond_t  not_full;
    int             done;
    size_t          head, tail, count;
    int             buf[RING_SIZE];
} shm_ring_t;

static void die(const char *msg) { perror(msg); exit(EXIT_FAILURE); }

int main(void) {
    // 1) Connect to existing shared memory (producer should have created it)
    int fd = shm_open(SHM_NAME, O_RDWR, 0666);
    if (fd == -1) {
        perror("shm_open");
        fprintf(stderr, "Start the producer first.\n");
        return 1;
    }

    // 2) Map it
    shm_ring_t *sh = mmap(NULL, sizeof(*sh), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (sh == MAP_FAILED) die("mmap");

    // 3) Consume until producer sets done and buffer is empty
    for (;;) {
        pthread_mutex_lock(&sh->mtx);
        while (sh->count == 0 && !sh->done) {
            pthread_cond_wait(&sh->not_empty, &sh->mtx);
        }

        if (sh->count == 0 && sh->done) {
            pthread_mutex_unlock(&sh->mtx);
            break;
        }

        int v = sh->buf[sh->head];
        sh->head = (sh->head + 1) % RING_SIZE;
        sh->count--;
        printf("       [CONS] got %d (count=%zu)\n", v, sh->count);

        pthread_cond_signal(&sh->not_full);
        pthread_mutex_unlock(&sh->mtx);

        // Simulate processing time
        usleep(50 * 1000);
    }

    printf("       [CONS] no more items. Cleaning up.\n");

    // 4) Cleanup: unmap, close, and unlink the shared memory name
    munmap(sh, sizeof(*sh));
    close(fd);
    if (shm_unlink(SHM_NAME) == -1) perror("shm_unlink");

    return 0;
}
