/*
 * detached_workers_qnx.c
 * Demonstrates applications of detached threads in QNX: fire-and-forget workers
 */


/*
 * Detachable (detached) threads are perfect for “fire-and-forget” work—tasks where the parent doesn’t need a return value or to synchronize at the end. Typical uses in QNX (and POSIX in general):

Per-request workers in lightweight servers (handle, finish, self-clean).

Background housekeeping: log flush, temp-file cleanup, metrics pusher.

One-shot async jobs kicked off from UI/IPC handlers.

Decoupled work where joining would just block the caller for no benefit.

Key property: once a detached thread exits, the OS reclaims its resources automatically; there’s no pthread_join()
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

typedef struct {
    int request_id;
    int work_secs;   // simulate variable work time
    char payload[32];
} task_t;

static void* worker(void* arg) {
    // Take ownership of the heap-allocated task and ensure it gets freed
    task_t* t = (task_t*)arg;

    printf("[Worker] start req=%d (tid=%lu, pid=%d), payload='%s'\n",
           t->request_id, (unsigned long)pthread_self(), getpid(), t->payload);

    // Simulate doing work
    sleep(t->work_secs);

    printf("[Worker] done   req=%d (tid=%lu)\n",
           t->request_id, (unsigned long)pthread_self());

    free(t); // self-clean (no joiner will free it)
    return NULL; // thread resources are auto-reclaimed because it's detached
}

int main(void) {
    printf("[Main] pid=%d, spawning detached workers…\n", getpid());

    pthread_attr_t attr;
    pthread_attr_init(&attr);
    // Make the threads detached so we don't need to join them
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);

    // Kick off a few fire-and-forget tasks
    for (int i = 1; i <= 4; ++i) {
        task_t* t = (task_t*)calloc(1, sizeof(*t));
        if (!t) { perror("calloc"); exit(EXIT_FAILURE); }
        t->request_id = i;
        t->work_secs  = 1 + (i % 3); // 2,3,1,2…
        snprintf(t->payload, sizeof(t->payload), "job-%d", i);

        pthread_t tid;
        int rc = pthread_create(&tid, &attr, worker, t);
        if (rc != 0) {
            perror("pthread_create");
            free(t);
            continue;
        }
        // No pthread_join() — the thread is detached
        printf("[Main] dispatched req=%d (tid=%lu)\n", i, (unsigned long)tid);
    }

    pthread_attr_destroy(&attr);

    // Keep process alive long enough to observe worker output
    // In a real server, the main thread would continue handling events.
    printf("[Main] doing other work while workers run…\n");
    sleep(5);

    printf("[Main] exiting (any finished detached threads already reclaimed)\n");
    return 0;
}
