// server.c
// Build: qcc -O2 -Wall -pthread -o server server.c
// Run:   ./server

#include <sys/dispatch.h>   // name_attach, name_open, ...
#include <sys/neutrino.h>   // MsgReceive, MsgReply, struct _pulse
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { OP_ECHO = 1, OP_ADD = 2, OP_MUL = 3 };

typedef struct {
    uint16_t type;   // OP_ECHO / OP_ADD / OP_MUL
    uint16_t rsvd;   // align
    int32_t  a;
    int32_t  b;
    char     text[64]; // used only for ECHO
} req_t;

typedef struct {
    int32_t status;   // EOK on success
    int32_t result;   // numeric result (ADD/MUL)
    char    text[64]; // echo text back (ECHO)
} rep_t;

int main(void) {
    name_attach_t *att = name_attach(NULL, "calc", 0);
    if (!att) { perror("name_attach"); return 1; }

    printf("[server] Ready. Name: \"calc\"  chid=%d\n", att->chid);
    printf("[server] Ops: ECHO (1), ADD (2), MUL (3). Ctrl+C to exit.\n");

    for (;;) {
        union {
            struct _pulse pulse;  // so we can distinguish pulses
            req_t         req;
        } msg;
        int rcvid = MsgReceive(att->chid, &msg, sizeof(msg), NULL);
        if (rcvid == -1) {
            perror("MsgReceive");
            continue;
        }

        if (rcvid == 0) { // pulse
            switch (msg.pulse.code) {
                case _PULSE_CODE_DISCONNECT:
                    // A client detached its connection; ack so the kernel cleans up
                    ConnectDetach(msg.pulse.scoid);
                    break;
                case _PULSE_CODE_UNBLOCK:
                    // A blocked client was unblocked (e.g., by a signal)
                    break;
                default:
                    // Ignore other pulses for this simple demo
                    break;
            }
            continue;
        }

        // It's a real message. Prepare a reply.
        rep_t rep = { .status = EOK, .result = 0, .text = {0} };

        switch (msg.req.type) {
            case OP_ECHO:
                snprintf(rep.text, sizeof(rep.text), "echo: %s", msg.req.text);
                break;
            case OP_ADD:
                rep.result = msg.req.a + msg.req.b;
                break;
            case OP_MUL:
                rep.result = msg.req.a * msg.req.b;
                break;
            default:
                rep.status = EINVAL;
                break;
        }

        if (MsgReply(rcvid, rep.status, &rep, sizeof(rep)) == -1) {
            perror("MsgReply");
        }
    }

    name_detach(att, 0);
    return 0;
}
