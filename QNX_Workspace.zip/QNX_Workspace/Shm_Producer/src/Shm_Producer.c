// shm_producer.c
// Build (QNX): qcc -O2 -Wall -pthread -o shm_producer shm_producer.c
// Run:         ./shm_producer

#define _XOPEN_SOURCE 700
#include <pthread.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define SHM_NAME    "/pc_shm_demo"
#define RING_SIZE   8
#define N_ITEMS     20

typedef struct {
    pthread_mutex_t mtx;
    pthread_cond_t  not_empty;
    pthread_cond_t  not_full;
    int             done;             // set by producer when finished
    size_t          head, tail, count;
    int             buf[RING_SIZE];
} shm_ring_t;

static void die(const char *msg) { perror(msg); exit(EXIT_FAILURE); }

int main(void) {
    // 1) Create (or recreate) the shared memory object
    int fd = shm_open(SHM_NAME, O_CREAT | O_RDWR, 0666);
    if (fd == -1) die("shm_open");

    if (ftruncate(fd, sizeof(shm_ring_t)) == -1) die("ftruncate");

    // 2) Map it
    shm_ring_t *sh = mmap(NULL, sizeof(*sh), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (sh == MAP_FAILED) die("mmap");

    // 3) Initialize shared struct (mutex/condvar must be PROCESS_SHARED)
    //    (Producer owns init in this simple demo)
    memset(sh, 0, sizeof(*sh));

    pthread_mutexattr_t mattr;
    pthread_condattr_t  cattr;
    if (pthread_mutexattr_init(&mattr) != 0) die("pthread_mutexattr_init");
    if (pthread_mutexattr_setpshared(&mattr, PTHREAD_PROCESS_SHARED) != 0) die("pthread_mutexattr_setpshared");

    if (pthread_condattr_init(&cattr) != 0) die("pthread_condattr_init");
    if (pthread_condattr_setpshared(&cattr, PTHREAD_PROCESS_SHARED) != 0) die("pthread_condattr_setpshared");

    if (pthread_mutex_init(&sh->mtx, &mattr) != 0) die("pthread_mutex_init");
    if (pthread_cond_init(&sh->not_empty, &cattr) != 0) die("pthread_cond_init not_empty");
    if (pthread_cond_init(&sh->not_full,  &cattr) != 0) die("pthread_cond_init not_full");

    pthread_mutexattr_destroy(&mattr);
    pthread_condattr_destroy(&cattr);

    // 4) Produce N_ITEMS
    for (int v = 1; v <= N_ITEMS; ++v) {
        // Simulate production time
        usleep(100 * 1000);

        pthread_mutex_lock(&sh->mtx);
        while (sh->count == RING_SIZE) {
            pthread_cond_wait(&sh->not_full, &sh->mtx);
        }

        sh->buf[sh->tail] = v;
        sh->tail = (sh->tail + 1) % RING_SIZE;
        sh->count++;
        printf("[PROD] put %d (count=%zu)\n", v, sh->count);

        pthread_cond_signal(&sh->not_empty);
        pthread_mutex_unlock(&sh->mtx);
    }

    // 5) Tell consumer we’re done
    pthread_mutex_lock(&sh->mtx);
    sh->done = 1;
    pthread_cond_broadcast(&sh->not_empty); // wake any waiting consumer
    pthread_mutex_unlock(&sh->mtx);

    printf("[PROD] finished. Leave shared memory for consumer to unlink.\n");

    // 6) Cleanup our mappings/FDs (don’t unlink here so consumer can still open if needed)
    munmap(sh, sizeof(*sh));
    close(fd);
    return 0;
}
