/*
 * pthread_cpu_waster.c
 * Demonstrate process/thread IDs using POSIX threads on QNX
 */

#include <pthread.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

static void* cpu_waster(void* arg) {
    (void)arg; // unused
    pthread_t tid = pthread_self();

    for (;;) {
        printf("CPU Waster Process ID: %d\n", getpid());
        // pthread_t is opaque; printing as unsigned long is portable enough for demos
        printf("CPU Waster Thread ID: %lu\n", (unsigned long)tid);
        printf("============================================================\n");
        fflush(stdout);
        sleep(5);
    }
    return NULL;
}

int main(void) {
    printf("Main Process ID: %d\n", getpid());
    printf("Main Thread ID:  %lu\n", (unsigned long)pthread_self());
    fflush(stdout);

    pthread_t t1, t2;
    int rc;

    rc = pthread_create(&t1, NULL, cpu_waster, NULL);
    if (rc) { perror("pthread_create t1"); exit(EXIT_FAILURE); }

    rc = pthread_create(&t2, NULL, cpu_waster, NULL);
    if (rc) { perror("pthread_create t2"); exit(EXIT_FAILURE); }

    // Keep main thread alive "forever"
    for (;;) {
        sleep(5);
        printf("Main Process ID: %d\n", getpid());
        fflush(stdout);
    }
    // not reached
    // pthread_exit(NULL); // alternative to keep the process alive
    return 0;
}
