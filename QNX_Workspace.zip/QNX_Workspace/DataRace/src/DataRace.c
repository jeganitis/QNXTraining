/*
 * pthread_data_race_qnx.c
 * Two threads updating the same variable (data race demo) — QNX/POSIX
 */

/*
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>

volatile unsigned long Write_count = 0;   // racy on purpose

static void* Write_App(void* arg) {
    (void)arg;
    for (unsigned long i = 0; i < 50000; ++i) {

    	Write_count++;
    }
    return NULL;
}

int main(void) {
    pthread_t t1, t2;

    if (pthread_create(&t1, NULL, Write_App, NULL) != 0) {
        perror("pthread_create t1");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&t2, NULL, Write_App, NULL) != 0) {
        perror("pthread_create t2");
        exit(EXIT_FAILURE);
    }

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Expected total: 100000\n");
    printf("Total Write Count (racy): %lu\n", Write_count);

    return 0;
}
*/

/*
 * pthread_data_race_qnx_atomic.c
 * Fix the race using QNX atomic increment
 */
/*
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <atomic.h>   // QNX atomics

volatile unsigned Write_count = 0;  // 'unsigned' matches QNX atomic_* prototypes

static void* Write_App(void* arg) {
    (void)arg;
    for (unsigned i = 0; i < 5000000; ++i) {
        // Atomically: Write_count += 1;
        atomic_add(&Write_count, 1);
        // If you needed the previous value, you could use:
        // (void)atomic_add_value(&Write_count, 1);
    }
    return NULL;
}

int main(void) {
    pthread_t t1, t2;

    if (pthread_create(&t1, NULL, Write_App, NULL) != 0) { perror("pthread_create t1"); exit(EXIT_FAILURE); }
    if (pthread_create(&t2, NULL, Write_App, NULL) != 0) { perror("pthread_create t2"); exit(EXIT_FAILURE); }

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Expected total: 100000\n");
    printf("Total Write Count (atomic): %u\n", Write_count);
    return 0;
}*/


/*
 * pthread_data_race_qnx_mutex.c
 * Fix the race using a pthread mutex
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

unsigned long Write_count = 0;       // no 'volatile' needed when protected by a mutex
pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

static void* Write_App(void* arg) {
    (void)arg;
    for (unsigned long i = 0; i < 50000; ++i) {
        pthread_mutex_lock(&lock);
        Write_count++;               // exclusively accessed
        pthread_mutex_unlock(&lock);
    }
    return NULL;
}

int main(void) {
    pthread_t t1, t2;

    if (pthread_create(&t1, NULL, Write_App, NULL) != 0) { perror("pthread_create t1"); exit(EXIT_FAILURE); }
    if (pthread_create(&t2, NULL, Write_App, NULL) != 0) { perror("pthread_create t2"); exit(EXIT_FAILURE); }

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    printf("Expected total: 100000\n");
    printf("Total Write Count (mutex): %lu\n", Write_count);
    return 0;
}
