/*
 * fork_example.c
 * Simple demonstration of process creation using fork() in QNX
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>

int main(void) {
    pid_t pid;

    printf("Parent process started. PID: %d\n", getpid());

    // Create a new process
    pid = fork();

    if (pid < 0) {
        // fork failed
        perror("fork");
        exit(EXIT_FAILURE);
    }
    else if (pid == 0) {
        // Child process
        printf("I am the child process! PID: %d, Parent PID: %d\n", getpid(), getppid());
        sleep(20); // simulate work
        printf("Child exiting...\n");
        exit(0);
    }
    else {
        // Parent process
        printf("I am the parent process! PID: %d, I created child PID: %d\n", getpid(), pid);
        sleep(30); // keep parent alive to observe child
        printf("Parent exiting...\n");
    }

    return 0;
}
