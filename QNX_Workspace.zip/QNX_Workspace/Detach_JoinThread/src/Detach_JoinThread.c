/*
 * detach_join_example.c
 * Demonstrates detached and joinable threads in QNX
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

void* joinable_thread_func(void* arg) {
    printf("[Joinable] Thread started. TID: %lu, PID: %d\n",
           (unsigned long)pthread_self(), getpid());
    sleep(2);
    printf("[Joinable] Thread exiting.\n");
    return (void*)42; // return value for pthread_join
}

void* detached_thread_func(void* arg) {
    printf("[Detached] Thread started. TID: %lu, PID: %d\n",
           (unsigned long)pthread_self(), getpid());
    sleep(2);
    printf("[Detached] Thread exiting.\n");
    return NULL; // this return value is ignored (no join)
}

int main(void) {
    pthread_t joinable_tid, detached_tid;
    pthread_attr_t attr;
    int rc;
    void* retval;

    printf("Main thread. TID: %lu, PID: %d\n",
           (unsigned long)pthread_self(), getpid());

    // Create joinable thread (default behavior)
    rc = pthread_create(&joinable_tid, NULL, joinable_thread_func, NULL);
    if (rc != 0) { perror("pthread_create joinable"); exit(EXIT_FAILURE); }

    // Create detached thread by setting thread attributes
    pthread_attr_init(&attr);
    pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);
    rc = pthread_create(&detached_tid, &attr, detached_thread_func, NULL);
    pthread_attr_destroy(&attr);
    if (rc != 0) { perror("pthread_create detached"); exit(EXIT_FAILURE); }

    // Wait (join) only the joinable thread
    rc = pthread_join(joinable_tid, &retval);
    if (rc != 0) { perror("pthread_join"); exit(EXIT_FAILURE); }
    printf("[Main] Joined with joinable thread, return value = %ld\n", (long)retval);

    // Detached thread cannot be joined — we just wait long enough to see its output
    //printf("[Main] Waiting for detached thread to finish (no join)...\n");
    sleep(5);

    printf("[Main] Exiting.\n");
    return 0;
}
