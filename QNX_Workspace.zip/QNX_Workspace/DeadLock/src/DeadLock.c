/*
 * deadlock_join_qnx.c
 * Demonstrates a deadlock with no mutex: mutual pthread_join()
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static pthread_t t1, t2;
static volatile int start_flag = 0; // simple spin barrier

void* thread_fn_1(void* arg) {
    (void)arg;
    // wait until main says both tids are ready
    while (!start_flag) { /* spin */ }
    printf("[T1] Attempting to join T2 (%lu)...\n", (unsigned long)t2);
    // DEADLOCK: T1 waits for T2, while T2 waits for T1
    pthread_join(t2, NULL);
    printf("[T1] (unreachable)\n");
    return NULL;
}

void* thread_fn_2(void* arg) {
    (void)arg;
    while (!start_flag) { /* spin */ }
    printf("[T2] Attempting to join T1 (%lu)...\n", (unsigned long)t1);
    pthread_join(t1, NULL);
    printf("[T2] (unreachable)\n");
    return NULL;
}

int main(void) {
    if (pthread_create(&t1, NULL, thread_fn_1, NULL) != 0) {
        perror("pthread_create t1"); exit(EXIT_FAILURE);
    }
    if (pthread_create(&t2, NULL, thread_fn_2, NULL) != 0) {
        perror("pthread_create t2"); exit(EXIT_FAILURE);
    }

    // publish that both tids are set; threads will proceed to join each other
    start_flag = 1;

    printf("[Main] T1=%lu, T2=%lu — both will now try to join each other.\n",
           (unsigned long)t1, (unsigned long)t2);
    printf("[Main] Program will deadlock now (no mutex involved).\n");

    // (Optional) sleep forever to keep main alive while deadlock is visible
    for (;;) sleep(10);
    return 0;
}
