// Supervisor.c
// Build (QNX): qcc -O2 -Wall -pthread -o supervisor Supervisor.c
// Run:         ./supervisor
//
// Listens on a named channel and prints pulses sent by workers.
// Uses ConnectClientInfo() to obtain the sender's PID from msg.pulse.scoid.

#include <sys/dispatch.h>   // name_attach(), name_detach()
#include <sys/neutrino.h>   // MsgReceive(), struct _pulse, ConnectClientInfo()
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>

enum { PULSE_HEARTBEAT = 1, PULSE_DONE = 2 };

int main(void) {
    // Create a named channel so workers can connect via name_open("sup_pulse", 0).
    name_attach_t *att = name_attach(NULL, "sup_pulse", 0);
    if (!att) { perror("name_attach"); return 1; }

    printf("[supervisor] ready. name=\"sup_pulse\"  chid=%d\n", att->chid);

    for (;;) {
        union { struct _pulse pulse; char raw[32]; } msg;

        int rcvid = MsgReceive(att->chid, &msg, sizeof(msg), NULL);
        if (rcvid == -1) {
            perror("MsgReceive");
            continue;
        }

        if (rcvid == 0) {
            // It's a pulse.
            switch (msg.pulse.code) {
            case _PULSE_CODE_DISCONNECT:
                // A client detached its connection; acknowledge so kernel cleans up.
                ConnectDetach(msg.pulse.scoid);
                break;

            case _PULSE_CODE_UNBLOCK:
                // A blocked sender was unblocked (e.g., by a signal). Ignore here.
                break;

            case PULSE_HEARTBEAT: {
                struct _client_info ci;
                if (ConnectClientInfo(msg.pulse.scoid, &ci, 0) == -1) {
                    perror("ConnectClientInfo");
                } else {
                    printf("[supervisor] heartbeat from pid=%d val=%d\n",
                           (int)ci.pid, msg.pulse.value.sival_int);
                }
                break;
            }

            case PULSE_DONE: {
                struct _client_info ci;
                if (ConnectClientInfo(msg.pulse.scoid, &ci, 0) == -1) {
                    perror("ConnectClientInfo");
                } else {
                    printf("[supervisor] worker pid=%d DONE (val=%d). Exiting.\n",
                           (int)ci.pid, msg.pulse.value.sival_int);
                }
                name_detach(att, 0);
                return 0;
            }

            default:
                printf("[supervisor] unknown pulse code=%d val=%d\n",
                       msg.pulse.code, msg.pulse.value.sival_int);
                break;
            }
            continue;
        }

        // Unexpected full message in this pulse-only demo: reply with error.
        MsgError(rcvid, ENOSYS);
    }
}
