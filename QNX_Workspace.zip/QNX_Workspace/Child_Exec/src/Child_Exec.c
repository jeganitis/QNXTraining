/*
 * child_program.c
 * This is the program the child process will run after exec()
 */
#include <stdio.h>
#include <unistd.h>

int main(int argc, char *argv[]) {
    printf("Child program started! PID: %d, Parent PID: %d\n", getpid(), getppid());

    // Print arguments passed from the parent
    for (int i = 0; argv[i] != NULL; i++) {
        printf("argv[%d] = %s\n", i, argv[i]);
    }

    printf("Child program exiting...\n");
    return 0;
}


