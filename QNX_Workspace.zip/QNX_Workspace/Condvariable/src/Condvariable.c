// qnx_condvar_mailbox.c
// Build (QNX): qcc -O2 -Wall -pthread -o qnx_condvar_mailbox qnx_condvar_mailbox.c
// (pick your variant as needed, e.g. -Vgcc_ntox86_64 or -Vgcc_ntoaarch64le)


/*CondVar Explaination:
 * Precondition: You must already hold mtx when you call it.

Queue & sleep: The calling thread is put to sleep on the condition variable not_full and the mutex mtx is released in the same atomic step
(so other threads can run and change the shared state).

Wake-up: Later, when another thread signals/broadcasts not_full, this waiting thread is unblocked and competes to re-acquire mtx.

Return with mutex locked: The function returns only after the thread has re-acquired mtx. At this point you still hold the mutex
and can safely re-check the predicate.
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  not_empty = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  not_full  = PTHREAD_COND_INITIALIZER;

static int mailbox_has_item = 0;  // predicate guarded by 'mtx'
static int mailbox_item     = 0;  // the one-slot payload

void* producer(void* arg) {
    (void)arg;
    for (int v = 1; v <= 5; ++v) {
        // produce 'v'
        usleep(100 * 1000); // simulate work (100 ms)

        pthread_mutex_lock(&mtx);
        // Wait until the mailbox is empty
        while (mailbox_has_item) {
            pthread_cond_wait(&not_full, &mtx);
        }
        // Put item
        mailbox_item = v;
        mailbox_has_item = 1;
        printf("[PROD] put %d\n", v);

        // Wake a waiting consumer
        pthread_cond_signal(&not_empty);
        pthread_mutex_unlock(&mtx);
    }

    return NULL;
}

void* consumer(void* arg) {
    (void)arg;
    for (int i = 0; i < 5; ++i) {
        pthread_mutex_lock(&mtx);
        // Wait while mailbox is empty
        while (!mailbox_has_item) {
            pthread_cond_wait(&not_empty, &mtx);
        }
        int v = mailbox_item;
        mailbox_has_item = 0;
        printf("                   [CONS] got %d\n", v);

        // Wake a waiting producer
        pthread_cond_signal(&not_full);
        pthread_mutex_unlock(&mtx);

        usleep(50 * 1000); // simulate processing (50 ms)
    }
    return NULL;
}

int main(void) {
    pthread_t tp, tc;

    if (pthread_create(&tp, NULL, producer, NULL) != 0) { perror("pthread_create producer"); exit(EXIT_FAILURE); }
    if (pthread_create(&tc, NULL, consumer, NULL) != 0) { perror("pthread_create consumer"); exit(EXIT_FAILURE); }

    pthread_join(tp, NULL);
    pthread_join(tc, NULL);

    puts("[MAIN] Done.");
    return 0;
}
