/*
 * pthread_sensor_samples_qnx.c
 * QNX/POSIX version of two threads processing sensor samples
 */

#include <pthread.h>
#include <unistd.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>
#include <time.h>

static volatile int g_sensor_process = 1;  // shared run flag

static void* process_sensor_data(void* arg) {
    const char* name = (const char*)arg;

    uint64_t sensor_sample = 0;
    struct timespec ts = { .tv_sec = 0, .tv_nsec = 2 * 1000 * 1000 }; // 2 ms

    while (g_sensor_process) {
        sensor_sample++;
        nanosleep(&ts, NULL);  // sleep ~2ms
    }

    printf("%s used %" PRIu64 " sensor samples\n", name, sensor_sample);
    return NULL;
}

int main(void) {
    pthread_t app_a, app_b;

    if (pthread_create(&app_a, NULL, process_sensor_data, (void*)"APP_A") != 0) {
        perror("pthread_create APP_A");
        exit(EXIT_FAILURE);
    }
    if (pthread_create(&app_b, NULL, process_sensor_data, (void*)"APP_B") != 0) {
        perror("pthread_create APP_B");
        exit(EXIT_FAILURE);
    }

    printf("APP_A and APP_B are processing sensor samples...\n");
    sleep(5);                 // run ~1s
    g_sensor_process = 0;     // signal threads to stop

    // join (wait for) both threads to finish
    pthread_join(app_b, NULL);
    pthread_join(app_a, NULL);

    return 0;
}



