/*
 * pthread_attr_example.c
 * Demonstrate setting POSIX thread attributes in QNX / Linux
 */

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sched.h>

void* thread_func(void* arg) {
    printf("Thread running. TID: %lu, PID: %d\n",
           (unsigned long)pthread_self(), getpid());
    sleep(2);
    printf("Thread exiting.\n");
    return NULL;
}

int main(void) {
    pthread_t thread;
    pthread_attr_t attr;
    struct sched_param schedParam;
    int rc;

    // Initialize the thread attributes object
    pthread_attr_init(&attr);

    // 1. Set detach state to JOINABLE (default) or DETACHED
    rc = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
    if (rc) { perror("pthread_attr_setdetachstate"); exit(EXIT_FAILURE); }

    // 2. Set stack size (must be >= PTHREAD_STACK_MIN)
    rc = pthread_attr_setstacksize(&attr, 64 * 1024); // 64 KB
    if (rc) { perror("pthread_attr_setstacksize"); exit(EXIT_FAILURE); }

    // 3. Set scheduling policy to FIFO (real-time) — requires privileges in QNX
    rc = pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    if (rc) { perror("pthread_attr_setschedpolicy"); exit(EXIT_FAILURE); }

    // 4. Set thread priority (for FIFO or RR policies)
    schedParam.sched_priority = 10; // range depends on OS config
    rc = pthread_attr_setschedparam(&attr, &schedParam);
    if (rc) { perror("pthread_attr_setschedparam"); exit(EXIT_FAILURE); }

    // 5. Explicitly specify that the scheduling attributes are to be used
    rc = pthread_attr_setinheritsched(&attr, PTHREAD_EXPLICIT_SCHED);
    if (rc) { perror("pthread_attr_setinheritsched"); exit(EXIT_FAILURE); }

    // Create the thread with the configured attributes
    rc = pthread_create(&thread, &attr, thread_func, NULL);
    if (rc) { perror("pthread_create"); exit(EXIT_FAILURE); }

    // Destroy the attribute object — no longer needed after pthread_create()
    pthread_attr_destroy(&attr);

    // Wait for the thread to finish (since it's joinable)
    pthread_join(thread, NULL);

    printf("Main thread exiting.\n");
    return 0;
}
