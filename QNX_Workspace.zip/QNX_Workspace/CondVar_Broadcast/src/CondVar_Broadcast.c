// qnx_condvar_mailbox_allconsume.c
// Build (QNX): qcc -O2 -Wall -pthread -o qnx_condvar_all qnx_condvar_mailbox_allconsume.c
// (pick a variant, e.g. -Vgcc_ntox86_64 or -Vgcc_ntoaarch64le)

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define N_CONSUMERS 3
#define N_ITEMS     6   // total items producer will make

static pthread_mutex_t mtx = PTHREAD_MUTEX_INITIALIZER;
/* cv_item:  broadcast when a new item generation is published (or at shutdown)
 * cv_all:   signal the producer when all consumers have finished the current item
 */
static pthread_cond_t  cv_item = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  cv_all  = PTHREAD_COND_INITIALIZER;

/* Shared state guarded by mtx */
static int item_value     = 0;          // payload for current generation
static int gen            = 0;          // generation counter (0 => none yet)
static int readers_done   = N_CONSUMERS;/* how many have consumed this gen
                                           initialize to N_CONSUMERS so the
                                           first production can proceed */
static int done           = 0;          // set true when producer is finished

static void* producer(void* arg) {
    (void)arg;

    for (int v = 1; v <= N_ITEMS; ++v) {
        usleep(100 * 1000); // simulate making the next item (100 ms)

        pthread_mutex_lock(&mtx);
        /* Wait until ALL consumers have finished the previous item. */
        while (readers_done < N_CONSUMERS) {
            pthread_cond_wait(&cv_all, &mtx);
        }

        /* Publish a new generation. */
        item_value   = v;
        gen++;                      // advance generation
        readers_done = 0;           // none have consumed this gen yet
        printf("[PROD] put %d \n", v);

        /* Wake everyone so each consumer can take this generation once. */
        pthread_cond_broadcast(&cv_item);
        pthread_mutex_unlock(&mtx);
    }

    /* After last item, make sure all consumers have consumed it, then shutdown. */
    pthread_mutex_lock(&mtx);
    while (readers_done < N_CONSUMERS) {
        pthread_cond_wait(&cv_all, &mtx);
    }
    done = 1;
    pthread_cond_broadcast(&cv_item);  // wake any consumers waiting for next gen
    pthread_mutex_unlock(&mtx);

    return NULL;
}

static void* consumer(void* arg) {
    (void)arg;
    int my_gen = 0;  // last generation this consumer processed

    for (;;) {
        pthread_mutex_lock(&mtx);

        /* Wait until there's a new generation we haven't seen, or shutdown. */
        while (gen == my_gen && !done) {
            pthread_cond_wait(&cv_item, &mtx);
        }

        if (done && gen == my_gen) {
            /* No new work and shutting down. */
            pthread_mutex_unlock(&mtx);
            printf("                     [CONS %lu] exiting\n",
                   (unsigned long)pthread_self());
            return NULL;
        }

        /* Consume the current generation exactly once. */
        int v = item_value;
        my_gen = gen;
        readers_done++;
        int last = (readers_done == N_CONSUMERS);

        /* If we were the last consumer for this generation, nudge producer. */
        if (last) {
            pthread_cond_signal(&cv_all);
        }
        pthread_mutex_unlock(&mtx);

        /* Do the actual processing outside the lock. */
        printf("                     [CONS] got %d \n",v);
        usleep(50 * 1000); // simulate work (50 ms)
    }
}

int main(void) {
    pthread_t tp, tc[N_CONSUMERS];

    if (pthread_create(&tp, NULL, producer, NULL) != 0) {
        perror("pthread_create producer"); exit(EXIT_FAILURE);
    }
    for (int i = 0; i < N_CONSUMERS; ++i) {
        if (pthread_create(&tc[i], NULL, consumer, NULL) != 0) {
            perror("pthread_create consumer"); exit(EXIT_FAILURE);
        }
    }

    pthread_join(tp, NULL);
    for (int i = 0; i < N_CONSUMERS; ++i) pthread_join(tc[i], NULL);

    puts("[MAIN] Done.");
    return 0;
}
