// client.c
// Build: qcc -O2 -Wall -pthread -o client client.c
// Run:   ./client

#include <sys/dispatch.h>   // name_open, name_close
#include <sys/neutrino.h>   // MsgSend
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

enum { OP_ECHO = 1, OP_ADD = 2, OP_MUL = 3 };

typedef struct {
    uint16_t type;
    uint16_t rsvd;
    int32_t  a;
    int32_t  b;
    char     text[64];
} req_t;

typedef struct {
    int32_t status;
    int32_t result;
    char    text[64];
} rep_t;

static void do_send(int coid, req_t *req) {
    rep_t rep;
    int r = MsgSend(coid, req, sizeof(*req), &rep, sizeof(rep));
    if (r == -1) { perror("MsgSend"); return; }
    if (rep.status != EOK) {
        printf("[client] Server error: %d\n", rep.status);
        return;
    }
    if (req->type == OP_ECHO) {
        printf("[client] ECHO reply: \"%s\"\n", rep.text);
    } else {
        printf("[client] result = %d\n", rep.result);
    }
}

int main(void) {
    int coid = name_open("calc", 0);
    if (coid == -1) { perror("name_open(calc)"); return 1; }

    req_t req = {0};

    // 1) ECHO
    req.type = OP_ECHO;
    snprintf(req.text, sizeof(req.text), "hello from client");
    do_send(coid, &req);

    // 2) ADD  21 + 21
    req = (req_t){ .type = OP_ADD, .a = 21, .b = 21 };
    do_send(coid, &req);

    // 3) MUL  7 * 8
    req = (req_t){ .type = OP_MUL, .a = 7, .b = 8 };
    do_send(coid, &req);

    sleep(100);
    name_close(coid);
    return 0;
}
