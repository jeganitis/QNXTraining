#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main() {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(5000);

    bind(server_fd, (struct sockaddr*)&addr, sizeof(addr));
    listen(server_fd, 1);
    printf("Waiting for connection...\n");

    int client_fd = accept(server_fd, NULL, NULL);
    char buf[256] = {0};
    read(client_fd, buf, sizeof(buf));
    printf("Received: %s\n", buf);

    write(client_fd, "ack from QNX server", 20);
    close(client_fd);
    close(server_fd);
    return 0;
}
