#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main() {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in server = {0};
    server.sin_family = AF_INET;
    server.sin_port = htons(5000);
    inet_pton(AF_INET, "192.168.46.130", &server.sin_addr);

    connect(sock, (struct sockaddr*)&server, sizeof(server));
    write(sock, "hello from QNX client", 22);

    char buf[256] = {0};
    read(sock, buf, sizeof(buf));
    printf("Server replied: %s\n", buf);
    close(sock);
    return 0;
}
