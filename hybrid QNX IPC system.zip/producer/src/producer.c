#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dispatch.h>
#include <sys/mman.h>
#include <sys/neutrino.h>
#include <time.h>
#include <unistd.h>

#include "ipc_protocol.h"

static int wait_for_free_slot(int chid, bool *slot_available, uint32_t slot_count) {
    for (;;) {
        for (uint32_t i = 0; i < slot_count; ++i) {
            if (slot_available[i]) {
                return (int)i;
            }
        }

        struct _pulse pulse;
        int rcvid = MsgReceivePulse(chid, &pulse, sizeof(pulse), NULL);
        if (rcvid == -1) {
            if (errno == EINTR) {
                continue;
            }
            perror("MsgReceivePulse");
            return -1;
        }

        if (pulse.code == IPC_PULSE_BUFFER_FREE) {
            int slot = pulse.value.sival_int;
            if (slot >= 0 && (uint32_t)slot < slot_count) {
                slot_available[slot] = true;
            }
        } else if (pulse.code == _PULSE_CODE_DISCONNECT) {
            ConnectDetach(pulse.scoid);
        }
    }
}

int main(int argc, char **argv) {
    uint32_t frame_size = 4096;
    uint32_t slot_count = 2;
    uint32_t frame_total = 50;

    if (argc > 1) {
        frame_total = (uint32_t)strtoul(argv[1], NULL, 10);
    }

    int consumer_coid = name_open(IPC_SERVICE_NAME, 0);
    if (consumer_coid == -1) {
        perror("name_open");
        return EXIT_FAILURE;
    }

    int pulse_chid = ChannelCreate(0);
    if (pulse_chid == -1) {
        perror("ChannelCreate");
        name_close(consumer_coid);
        return EXIT_FAILURE;
    }

    ipc_init_request_t req;
    memset(&req, 0, sizeof(req));
    req.type = IPC_CTRL_INIT;
    req.version = IPC_PROTOCOL_VERSION;
    req.requested_frame_size = frame_size;
    req.requested_slot_count = slot_count;
    req.producer_pid = getpid();
    req.producer_chid = pulse_chid;

    ipc_init_reply_t reply;
    memset(&reply, 0, sizeof(reply));

    if (MsgSend(consumer_coid, &req, sizeof(req), &reply, sizeof(reply)) == -1) {
        perror("MsgSend INIT");
        ChannelDestroy(pulse_chid);
        name_close(consumer_coid);
        return EXIT_FAILURE;
    }

    int shm_fd = shm_open(reply.shm_name, O_RDWR, 0);
    if (shm_fd == -1) {
        perror("shm_open");
        ChannelDestroy(pulse_chid);
        name_close(consumer_coid);
        return EXIT_FAILURE;
    }

    void *shm_base = mmap(NULL, reply.shm_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
    if (shm_base == MAP_FAILED) {
        perror("mmap");
        close(shm_fd);
        ChannelDestroy(pulse_chid);
        name_close(consumer_coid);
        return EXIT_FAILURE;
    }

    ipc_shm_header_t *hdr = (ipc_shm_header_t *)shm_base;
    if (hdr->magic != IPC_SHM_MAGIC || hdr->version != IPC_PROTOCOL_VERSION) {
        fprintf(stderr, "Shared memory header mismatch\n");
        munmap(shm_base, reply.shm_size);
        close(shm_fd);
        ChannelDestroy(pulse_chid);
        name_close(consumer_coid);
        return EXIT_FAILURE;
    }

    bool *slot_available = calloc(reply.slot_count, sizeof(bool));
    if (slot_available == NULL) {
        perror("calloc");
        munmap(shm_base, reply.shm_size);
        close(shm_fd);
        ChannelDestroy(pulse_chid);
        name_close(consumer_coid);
        return EXIT_FAILURE;
    }

    for (uint32_t i = 0; i < reply.slot_count; ++i) {
        slot_available[i] = true;
    }

    printf("Producer started slots=%u frame_size=%u total=%u\n",
           reply.slot_count,
           reply.frame_size,
           frame_total);

    struct timespec tick = {0, 20 * 1000 * 1000};

    for (uint32_t frame_id = 0; frame_id < frame_total; ++frame_id) {
        int slot = wait_for_free_slot(pulse_chid, slot_available, reply.slot_count);
        if (slot < 0) {
            break;
        }

        uint8_t *slot_ptr = (uint8_t *)shm_base + reply.data_offset +
                            ((size_t)slot * reply.slot_stride);

        uint32_t stamp = frame_id;
        memcpy(slot_ptr, &stamp, sizeof(stamp));

        for (uint32_t i = sizeof(stamp); i < reply.frame_size; ++i) {
            slot_ptr[i] = (uint8_t)((frame_id + i) & 0xFFu);
        }

        slot_available[slot] = false;

        if (MsgSendPulse(consumer_coid,
                         SIGEV_PULSE_PRIO_INHERIT,
                         IPC_PULSE_FRAME_READY,
                         slot) == -1) {
            perror("MsgSendPulse FRAME_READY");
            break;
        }

        nanosleep(&tick, NULL);
    }

    if (MsgSendPulse(consumer_coid,
                     SIGEV_PULSE_PRIO_INHERIT,
                     IPC_PULSE_SESSION_DONE,
                     0) == -1) {
        perror("MsgSendPulse SESSION_DONE");
    }

    free(slot_available);
    munmap(shm_base, reply.shm_size);
    close(shm_fd);
    ChannelDestroy(pulse_chid);
    name_close(consumer_coid);

    return EXIT_SUCCESS;
}
