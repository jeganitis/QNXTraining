#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/dispatch.h>
#include <sys/netmgr.h>
#include <sys/mman.h>
#include <sys/neutrino.h>
#include <time.h>
#include <unistd.h>

#include "ipc_protocol.h"

typedef union {
    struct _pulse pulse;
    ipc_control_request_t control;
    ipc_init_request_t init;
    ipc_shutdown_request_t shutdown;
} recv_any_t;

static void cleanup_session(name_attach_t *attach,
                            char *shm_name,
                            int *shm_fd,
                            void **shm_base,
                            size_t *shm_size,
                            int *producer_coid) {
    if (*producer_coid >= 0) {
        ConnectDetach(*producer_coid);
        *producer_coid = -1;
    }

    if (*shm_base != MAP_FAILED && *shm_base != NULL && *shm_size > 0) {
        munmap(*shm_base, *shm_size);
        *shm_base = MAP_FAILED;
        *shm_size = 0;
    }

    if (*shm_fd >= 0) {
        close(*shm_fd);
        *shm_fd = -1;
    }

    if (shm_name[0] != '\0') {
        shm_unlink(shm_name);
        shm_name[0] = '\0';
    }

    if (attach != NULL) {
        name_detach(attach, 0);
    }
}

int main(void) {
    name_attach_t *attach = name_attach(NULL, IPC_SERVICE_NAME, 0);
    if (attach == NULL) {
        perror("name_attach");
        return EXIT_FAILURE;
    }

    printf("Consumer listening on %s (chid=%d)\n", IPC_SERVICE_NAME, attach->chid);

    bool running = true;
    int producer_coid = -1;
    int shm_fd = -1;
    void *shm_base = MAP_FAILED;
    size_t shm_size = 0;
    char shm_name[IPC_SHM_NAME_MAX] = {0};
    ipc_shm_header_t *hdr = NULL;

    while (running) {
        recv_any_t msg;
        memset(&msg, 0, sizeof(msg));

        int rcvid = MsgReceive(attach->chid, &msg, sizeof(msg), NULL);
        if (rcvid < 0) {
            if (errno == EINTR) {
                continue;
            }
            perror("MsgReceive");
            break;
        }

        if (rcvid == 0) {
            switch (msg.pulse.code) {
                case IPC_PULSE_FRAME_READY: {
                    int slot_index = msg.pulse.value.sival_int;
                    if (hdr == NULL || shm_base == MAP_FAILED) {
                        fprintf(stderr, "FRAME_READY received before session init\n");
                        break;
                    }
                    if (slot_index < 0 || (uint32_t)slot_index >= hdr->slot_count) {
                        fprintf(stderr, "FRAME_READY invalid slot %d\n", slot_index);
                        break;
                    }

                    uint8_t *slot_ptr = (uint8_t *)shm_base + hdr->data_offset +
                                        ((size_t)slot_index * hdr->slot_stride);
                    uint32_t sample = 0;
                    memcpy(&sample, slot_ptr, sizeof(sample));
                    printf("Consumed slot=%d sample=0x%08" PRIx32 "\n", slot_index, sample);

                    if (producer_coid >= 0) {
                        if (MsgSendPulse(producer_coid,
                                         SIGEV_PULSE_PRIO_INHERIT,
                                         IPC_PULSE_BUFFER_FREE,
                                         slot_index) == -1) {
                            perror("MsgSendPulse BUFFER_FREE");
                        }
                    }
                    break;
                }
                case IPC_PULSE_SESSION_DONE:
                    printf("SESSION_DONE received\n");
                    running = false;
                    break;
                case _PULSE_CODE_DISCONNECT:
                    ConnectDetach(msg.pulse.scoid);
                    break;
                default:
                    printf("Unhandled pulse code=%d value=%d\n",
                           msg.pulse.code,
                           msg.pulse.value.sival_int);
                    break;
            }
            continue;
        }

        switch (msg.control.type) {
            case IPC_CTRL_INIT: {
                if (msg.init.version != IPC_PROTOCOL_VERSION) {
                    MsgError(rcvid, EPROTO);
                    break;
                }

                if (shm_base != MAP_FAILED || shm_fd >= 0) {
                    MsgError(rcvid, EBUSY);
                    break;
                }

                uint32_t slot_count = msg.init.requested_slot_count;
                uint32_t frame_size = msg.init.requested_frame_size;
                if (slot_count < 2 || frame_size == 0) {
                    MsgError(rcvid, EINVAL);
                    break;
                }

                snprintf(shm_name,
                         sizeof(shm_name),
                         "/qnx_frames_%d_%ld",
                         (int)getpid(),
                         (long)time(NULL));

                shm_fd = shm_open(shm_name, O_CREAT | O_EXCL | O_RDWR, 0600);
                if (shm_fd == -1) {
                    perror("shm_open");
                    MsgError(rcvid, errno);
                    shm_name[0] = '\0';
                    break;
                }

                size_t data_offset = sizeof(ipc_shm_header_t);
                size_t slot_stride = frame_size;
                shm_size = data_offset + ((size_t)slot_count * slot_stride);

                if (ftruncate(shm_fd, (off_t)shm_size) == -1) {
                    perror("ftruncate");
                    MsgError(rcvid, errno);
                    close(shm_fd);
                    shm_fd = -1;
                    shm_unlink(shm_name);
                    shm_name[0] = '\0';
                    shm_size = 0;
                    break;
                }

                shm_base = mmap(NULL, shm_size, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd, 0);
                if (shm_base == MAP_FAILED) {
                    perror("mmap");
                    MsgError(rcvid, errno);
                    close(shm_fd);
                    shm_fd = -1;
                    shm_unlink(shm_name);
                    shm_name[0] = '\0';
                    shm_size = 0;
                    break;
                }

                hdr = (ipc_shm_header_t *)shm_base;
                hdr->magic = IPC_SHM_MAGIC;
                hdr->version = IPC_PROTOCOL_VERSION;
                hdr->slot_count = slot_count;
                hdr->frame_size = frame_size;
                hdr->slot_stride = (uint32_t)slot_stride;
                hdr->data_offset = (uint32_t)data_offset;

                producer_coid = ConnectAttach(ND_LOCAL_NODE,
                                              msg.init.producer_pid,
                                              msg.init.producer_chid,
                                              _NTO_SIDE_CHANNEL,
                                              0);
                if (producer_coid == -1) {
                    perror("ConnectAttach producer");
                    MsgError(rcvid, errno);
                    munmap(shm_base, shm_size);
                    shm_base = MAP_FAILED;
                    hdr = NULL;
                    close(shm_fd);
                    shm_fd = -1;
                    shm_unlink(shm_name);
                    shm_name[0] = '\0';
                    shm_size = 0;
                    break;
                }

                ipc_init_reply_t reply;
                memset(&reply, 0, sizeof(reply));
                reply.status = EOK;
                strncpy(reply.shm_name, shm_name, sizeof(reply.shm_name) - 1);
                reply.shm_size = (uint32_t)shm_size;
                reply.slot_count = slot_count;
                reply.frame_size = frame_size;
                reply.slot_stride = (uint32_t)slot_stride;
                reply.data_offset = (uint32_t)data_offset;

                if (MsgReply(rcvid, EOK, &reply, sizeof(reply)) == -1) {
                    perror("MsgReply INIT");
                    running = false;
                } else {
                    printf("Session initialized shm=%s size=%u slots=%u frame=%u\n",
                           reply.shm_name,
                           reply.shm_size,
                           reply.slot_count,
                           reply.frame_size);
                }
                break;
            }
            case IPC_CTRL_SHUTDOWN:
                MsgReply(rcvid, EOK, NULL, 0);
                running = false;
                break;
            default:
                MsgError(rcvid, ENOSYS);
                break;
        }
    }

    cleanup_session(attach, shm_name, &shm_fd, &shm_base, &shm_size, &producer_coid);
    printf("Consumer shutdown complete\n");
    return EXIT_SUCCESS;
}
