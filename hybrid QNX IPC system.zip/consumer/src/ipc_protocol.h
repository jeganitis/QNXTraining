#ifndef IPC_PROTOCOL_H
#define IPC_PROTOCOL_H

#include <sys/neutrino.h>
#include <sys/dispatch.h>
#include <stdint.h>

#define IPC_SERVICE_NAME "qnx.frame.ipc"
#define IPC_PROTOCOL_VERSION 1u
#define IPC_SHM_NAME_MAX 128u
#define IPC_SHM_MAGIC 0x49504331u

typedef enum {
    IPC_CTRL_INIT = 1,
    IPC_CTRL_SHUTDOWN = 2
} ipc_ctrl_type_t;

typedef enum {
    IPC_PULSE_FRAME_READY = _PULSE_CODE_MINAVAIL,
    IPC_PULSE_BUFFER_FREE = _PULSE_CODE_MINAVAIL + 1,
    IPC_PULSE_SESSION_DONE = _PULSE_CODE_MINAVAIL + 2
} ipc_pulse_code_t;

typedef struct {
    uint16_t type;
    uint16_t version;
    uint32_t requested_frame_size;
    uint32_t requested_slot_count;
    pid_t producer_pid;
    int producer_chid;
} ipc_init_request_t;

typedef struct {
    uint16_t type;
    uint16_t version;
} ipc_shutdown_request_t;

typedef union {
    uint16_t type;
    ipc_init_request_t init;
    ipc_shutdown_request_t shutdown;
} ipc_control_request_t;

typedef struct {
    int32_t status;
    char shm_name[IPC_SHM_NAME_MAX];
    uint32_t shm_size;
    uint32_t slot_count;
    uint32_t frame_size;
    uint32_t slot_stride;
    uint32_t data_offset;
} ipc_init_reply_t;

typedef struct {
    uint32_t magic;
    uint32_t version;
    uint32_t slot_count;
    uint32_t frame_size;
    uint32_t slot_stride;
    uint32_t data_offset;
} ipc_shm_header_t;

#endif
